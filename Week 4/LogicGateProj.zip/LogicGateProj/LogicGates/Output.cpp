#include "Output.h"
bool Output::getOutput() {
    return input->getOutput();
}
