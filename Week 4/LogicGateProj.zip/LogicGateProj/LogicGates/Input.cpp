#include "Input.h"


void Input::setValue(bool newValue){
    value = newValue;
}
bool Input::getOutput() {
    return value;
}

